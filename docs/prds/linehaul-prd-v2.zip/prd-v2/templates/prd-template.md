# PRD Template

**Version:** 1.0  
**Status:** Draft | Review | Approved | Implemented | Deprecated  
**Last Updated:** [Date]  
**Author:** [Name]  

---

## 1. Feature Identity

### 1.1 Name
[Official feature name]

### 1.2 Portal(s)
- [ ] Driver
- [ ] Carrier
- [ ] Admin

### 1.3 One-Line Summary
[Single sentence describing what this feature does]

### 1.4 Business Value
[Why this feature exists. What problem it solves.]

---

## 2. System Context

### 2.1 Dependencies
- PRD-XXX: [Name] — [Why needed]

### 2.2 Dependents
- PRD-XXX: [Name] — [Why it depends on this]

---

## 3. Data Model

```
EntityName
├── field_id (UUID, PK)
├── field_name (type, constraints)
└── field_name (type, constraints)
```

---

## 4. States & Transitions

```
[STATE_A] ──(action)──► [STATE_B] ──(action)──► [STATE_C]
```

| State | Description | Who Can Enter |
|-------|-------------|---------------|
| STATE_A | | |
| STATE_B | | |

---

## 5. Rules & Constraints

| Rule | Description |
|------|-------------|
| R1 | [Rule description] |
| R2 | [Rule description] |

---

## 6. User Experience

### 6.1 Entry Points
- [How users access this feature]

### 6.2 Key Flows
1. User does X
2. System responds with Y
3. User sees Z

---

## 7. Admin Controls

| Action | Description | Confirmation? |
|--------|-------------|---------------|
| [Action] | [What it does] | Yes/No |

---

## 8. Events & Side Effects

| Trigger | Event | Side Effects |
|---------|-------|--------------|
| [When X happens] | [Event name] | [What else happens] |

---

## 9. Non-Goals

This feature explicitly does NOT:
- ❌ [Thing it doesn't do]
- ❌ [Another thing it doesn't do]

---

## 10. Impact Analysis Guidance

When changing this PRD, check:

| Change | Affected PRDs |
|--------|---------------|
| [Change type] | PRD-XXX |

---

## 11. Changelog

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | [Date] | [Author] | Initial draft |
